# Kravchuk Encyclopedia: working master

- main.tex uses the AMS amsbook class.
- Introduction chapter is present as chapters/00-introduction.tex and included first.
- All 25 chapter/appendix includes resolve: Introduction, 18 topical chapters, 6 appendices.
- Updated source files are taken from the uploaded Kravchuk_Encyclopedia.zip.
- main.pdf is the compiled PDF supplied by the user, not a PDF compiled during this update.
- Original uploads and overwritten source versions are preserved in project-archive/.
- Build auxiliary files were not copied into the active project.

## Pending
- Integrate the latest sums/moments manuscript. The moments-updated manuscript is not in this upload; earlier supplied sums papers are retained in supporting-papers/.
- Mathematical claims and literature priority still require editorial review.

## Matrix integration
The matrix definitions and verified tables for N=2,4,7,8 are now included in the book chapters and Appendix A. The existing main.pdf is an older user-supplied build and does not contain these source changes. Compile main.tex twice to refresh cross-references and the table of contents.


## Split-quaternion article integration
Archived `sources/KrawtchoukFeynman.pdf` and developed ten existing sections across current Chapters 7--10, emphasizing Section 7. Added a verified bibliography entry, determinant/component corrections, and explicit normalization reconciliation. See `sources/INTEGRATION_KrawtchoukFeynman.md` for the source-to-topic map, checks, and remaining scope. Main PDF not rebuilt.
