# Change log

## Project consolidation
- Recovered nested chapter sources and retained the user-edited outer main.tex.
- Preserved the original archive and supplied sums-paper sources.
- Added project status, missing-material checklist, and working conventions.
- Did not insert missing introduction or moments updates.

## Introduction update
- Installed the newly uploaded source project, including chapters/00-introduction.tex and its main.tex include.
- Verified all 25 includes. Preserved overwritten source versions and the uploaded archive.
- Retained the user-supplied compiled main.pdf; no compilation performed here.

## Matrix material integrated into the Encyclopedia
- Added conventions, generators, recurrence intertwinings, raw/orthogonal transforms, and symmetric-matrix definitions in their topical chapters.
- Added all twenty full matrices for N=2,4,7,8 to Appendix A using separate source fragments.
- Added cross-references and updated CONTENTS.md; prior versions preserved in project-archive/.
- Existing main.pdf predates this source integration and has not been recompiled.


## Split-quaternion article integration
Archived `sources/KrawtchoukFeynman.pdf` and developed ten existing sections across current Chapters 7--10, emphasizing Section 7. Added a verified bibliography entry, determinant/component corrections, and explicit normalization reconciliation. See `sources/INTEGRATION_KrawtchoukFeynman.md` for the source-to-topic map, checks, and remaining scope. Main PDF not rebuilt.
