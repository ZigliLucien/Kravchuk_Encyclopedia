# Integration of KrawtchoukFeynman.pdf

## Archived source
- Original supplied PDF: `sources/KrawtchoukFeynman.pdf` (36 pages).
- Jerzy Kocik, *Krawtchouk matrices from the Feynman path integral and from the split quaternions*.
- Verified record: https://doi.org/10.48550/arXiv.1604.00109 (2016).

## Distribution into the current book
Chapter numbers below include the numbered introduction.

| Current chapter | Existing section | Integrated content |
| --- | --- | --- |
| 7: Lie Algebras | so(2,1) explained | Pure split space, Lorentz metric, commutators, adjoint matrices |
| 7 | so(2,1) spinors | Real spinors, adjoint vectors, double covering, rotations and boosts |
| 7 | Quaternions and Clifford algebras | Multiplication, conjugation, norm, zero divisors, matrix and Clifford realizations |
| 7 | S and so(2,1) tensors | Group versus infinitesimal lifts; distinction between Phi, S, and orthogonal U |
| 7 | Three-dimensional simple Lie algebras | Compact and split real forms, complexification, global group caveats |
| 8: Lie Groups and Reflections | Reflections | Non-null reflections, Hadamard conjugation and time orientation |
| 8 | Krawtchouk matrices as group elements | GL(2,R) formulation; determinant correction to the source |
| 9: Representations | Splitting formula | Symmetric powers, derivative representation, master equation and reversal symmetries |
| 10: Quantum Probability and Tensor Algebra | Flip operator and quantum random walk | Cube flips, orbit-average normalization and stochastic versus unitary evolution |
| 10 | Krawtchouk matrices as eigenvectors | Tensor diagonalization and full-cube versus symmetric-sector multiplicities |

## Editorial conventions and corrections
- Ordinary commutator XY-YX throughout the book; the source's half-commutator is explicitly distinguished.
- H has determinant -2. No nonzero real scalar multiple is in SL(2,R).
- SL(2,R) double covers SO^+(1,2), not every component of SO(1,2).
- Phi_N, S_N=Phi_N B_N, and the binomially normalized orthogonal involution U_N are distinguished.
- Orbit averages, not unnormalized orbit sums, yield the book's A_N on the symmetric tensor sector.

## Scope and verification
This is a focused integration of Section 7's foundational split-quaternion and tensor-representation material, with its cube/quantum context. It is not a complete transcription or integration of all 36 pages. Remaining path-integral, twiston, generalized-parameter and later spectral developments require separate treatment; existing placeholders for those topics are retained.

Exact arithmetic checks: split-unit products, both elementary Hadamard identities, all three displayed Lorentz-generator metric identities; reversal symmetries and weighted orthogonality for N=1 through 8. Existing N=3,5 appendix tables and Chapter 3 updates are preserved.

The main PDF has not been rebuilt. The current deliverable is the updated LaTeX source and archived input PDF.
