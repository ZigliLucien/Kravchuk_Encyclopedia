# Change log

## Project consolidation
- Recovered nested chapter sources and retained the user-edited outer main.tex.
- Preserved the original archive and supplied sums-paper sources.
- Added project status, missing-material checklist, and working conventions.
- Did not insert missing introduction or moments updates.

## Introduction update
- Installed the newly uploaded source project, including chapters/00-introduction.tex and its main.tex include.
- Verified all 25 includes. Preserved overwritten source versions and the uploaded archive.
- Retained the user-supplied compiled main.pdf; no compilation performed here.

## Matrix material integrated into the Encyclopedia
- Added conventions, generators, recurrence intertwinings, raw/orthogonal transforms, and symmetric-matrix definitions in their topical chapters.
- Added all twenty full matrices for N=2,4,7,8 to Appendix A using separate source fragments.
- Added cross-references and updated CONTENTS.md; prior versions preserved in project-archive/.
- Existing main.pdf predates this source integration and has not been recompiled.


## Split-quaternion article integration
Archived `sources/KrawtchoukFeynman.pdf` and developed ten existing sections across current Chapters 7--10, emphasizing Section 7. Added a verified bibliography entry, determinant/component corrections, and explicit normalization reconciliation. See `sources/INTEGRATION_KrawtchoukFeynman.md` for the source-to-topic map, checks, and remaining scope. Main PDF not rebuilt.


## Consolidation after source comparison

- Kept project notation, including the already established Pascal matrix P_N (not a new C_N). Renamed powers-of-two Pascal weights W_N to avoid the parity matrix D_N. Added a central article-to-book dictionary in main.tex.
- Developed the elementary-symmetric-function/energy identity once in current Chapter 5; the twiston section in current Chapter 10 now gives only its model, interpretation, example, and source corrections.
- Developed signed paths in current Chapter 3, with an explicit amplitude/probability caveat.
- Extended the existing binomial-basis section in current Chapter 15 with its generating-function proof and explicit complementary-column eigenvectors of Phi_N, including the even-order central column and multiplicities. The basic binomial-column identity was already present before this consolidation.
- Kept the coefficient proof of the master equation in Random Walks, the tensor explanation in Representations, and replaced repeated derivations/normalizations elsewhere by cross-references.
- Verification: exact Pascal/eigenvector/completeness/multiplicity checks and exhaustive subset-energy/signed-path checks for N=0 through 8; source environments, references and citation keys checked. Prior N=3,5 appendices preserved byte-for-byte.
- Backup: project-archive/before-twiston-consolidation.zip.
- main.pdf has not been rebuilt; source-only validation is not a TeX compilation or visual-layout check.
